/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

/**
 *
 * @author usci
 */
public class SodaCan {

 
  private int d,h;
  
  public SodaCan(int d , int h){
    this.d = d;
    this.h = h;
  }
  
  public double getVolume() {
     double v1 = Math.PI * (d/2.0)*(d/2.0)*h ;
     return Math.round(v1*100)/100.00;
  }
  
  public double getSurfaceArea(){
     double a1 = 2 * Math.PI * (d/2.0) * (h)+ (2*Math.PI*(d/2.0)*(d/2.0));
     return Math.round(a1*100)/100.00;
  }
   

}
