/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

/**
 *
 * @author usci
 */
import java.util.Scanner;

public class SodaTester {
     
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        
        
        
        System.out.print("Enter height: ");
        int h = in.nextInt();
        
       
        
        System.out.print("Enter diameter: ");
        int d = in.nextInt();
        
       SodaCan x = new SodaCan(d,h) ;
        
        System.out.println("Volume: "+x.getVolume());
        System.out.println("Surface area: "+x.getSurfaceArea());
        
   
    }
}
